package com.zosh.FoodAllergenApp.request;



import java.util.List;

import com.zosh.FoodAllergenApp.model.Category;
import com.zosh.FoodAllergenApp.model.IngredientsItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateFoodRequest {
	

    
    private String name;
    private String description;
    private Long price;
    
  
    private Category category;
    private List<String> images;

   
    private Long restaurantId;
    
    private boolean vegetarian;
    private boolean seasonal;
    
    
    private List<IngredientsItem> ingredients;

    // Add allergens field
    private List<String> allergens;  // Add allergens to the request object

}
