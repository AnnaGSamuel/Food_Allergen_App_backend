package com.zosh.FoodAllergenApp.repository;

import com.zosh.FoodAllergenApp.model.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

}
