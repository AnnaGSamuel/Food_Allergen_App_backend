package com.zosh.FoodAllergenApp.repository;

import com.zosh.FoodAllergenApp.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {


//    CartItem findByFoodIsContaining

}
