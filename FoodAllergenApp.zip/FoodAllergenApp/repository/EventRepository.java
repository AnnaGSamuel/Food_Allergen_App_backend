package com.zosh.FoodAllergenApp.repository;

import java.util.List;

import com.zosh.FoodAllergenApp.model.Events;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EventRepository extends JpaRepository<Events, Long>{

	public List<Events> findEventsByRestaurantId(Long id);
}
