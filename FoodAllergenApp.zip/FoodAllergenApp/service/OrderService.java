package com.zosh.FoodAllergenApp.service;

import java.util.List;

//import com.stripe.exception.StripeException;
import com.zosh.FoodAllergenApp.Exception.CartException;
import com.zosh.FoodAllergenApp.Exception.OrderException;
import com.zosh.FoodAllergenApp.Exception.RestaurantException;
import com.zosh.FoodAllergenApp.Exception.UserException;
import com.zosh.FoodAllergenApp.model.Order;
import com.zosh.FoodAllergenApp.model.PaymentResponse;
import com.zosh.FoodAllergenApp.model.User;
import com.zosh.FoodAllergenApp.request.CreateOrderRequest;

public interface OrderService {
	
	 public PaymentResponse createOrder(CreateOrderRequest order, User user) throws UserException, RestaurantException, CartException;//, StripeException;
	 
	 public Order updateOrder(Long orderId, String orderStatus) throws OrderException;
	 
	 public void cancelOrder(Long orderId) throws OrderException;
	 
	 public List<Order> getUserOrders(Long userId) throws OrderException;
	 
	 public List<Order> getOrdersOfRestaurant(Long restaurantId,String orderStatus) throws OrderException, RestaurantException;
	 

}
