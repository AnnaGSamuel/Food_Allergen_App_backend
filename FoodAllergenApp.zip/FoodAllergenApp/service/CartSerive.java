package com.zosh.FoodAllergenApp.service;

import com.zosh.FoodAllergenApp.Exception.CartException;
import com.zosh.FoodAllergenApp.Exception.CartItemException;
import com.zosh.FoodAllergenApp.Exception.FoodException;
import com.zosh.FoodAllergenApp.Exception.UserException;
import com.zosh.FoodAllergenApp.model.Cart;
import com.zosh.FoodAllergenApp.model.CartItem;
import com.zosh.FoodAllergenApp.model.Food;
import com.zosh.FoodAllergenApp.model.User;
import com.zosh.FoodAllergenApp.request.AddCartItemRequest;
import com.zosh.FoodAllergenApp.request.UpdateCartItemRequest;

public interface CartSerive {

	public CartItem addItemToCart(AddCartItemRequest req, String jwt) throws UserException, FoodException, CartException, CartItemException;

	public CartItem updateCartItemQuantity(Long cartItemId,int quantity) throws CartItemException;

	public Cart removeItemFromCart(Long cartItemId, String jwt) throws UserException, CartException, CartItemException;

	public Long calculateCartTotals(Cart cart) throws UserException;
	
	public Cart findCartById(Long id) throws CartException;
	
	public Cart findCartByUserId(Long userId) throws CartException, UserException;
	
	public Cart clearCart(Long userId) throws CartException, UserException;
	

	

}
