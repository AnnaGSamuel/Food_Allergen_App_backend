package com.zosh.FoodAllergenApp.service;

import java.util.List;

import com.zosh.FoodAllergenApp.Exception.ReviewException;
import com.zosh.FoodAllergenApp.model.Review;
import com.zosh.FoodAllergenApp.model.User;
import com.zosh.FoodAllergenApp.request.ReviewRequest;

public interface ReviewSerive {
	
    public Review submitReview(ReviewRequest review,User user);
    public void deleteReview(Long reviewId) throws ReviewException;
    public double calculateAverageRating(List<Review> reviews);
}
