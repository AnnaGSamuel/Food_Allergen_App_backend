package com.zosh.FoodAllergenApp.service;

import com.zosh.FoodAllergenApp.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
