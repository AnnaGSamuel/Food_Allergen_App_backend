package com.zosh.FoodAllergenApp.service;

import com.zosh.FoodAllergenApp.model.PasswordResetToken;

public interface PasswordResetTokenService {

	public PasswordResetToken findByToken(String token);

	public void delete(PasswordResetToken resetToken);

}
