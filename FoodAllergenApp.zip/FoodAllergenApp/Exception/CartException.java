package com.zosh.FoodAllergenApp.Exception;

public class CartException extends Exception {

	public CartException(String message) {
		super(message);
	}

}
