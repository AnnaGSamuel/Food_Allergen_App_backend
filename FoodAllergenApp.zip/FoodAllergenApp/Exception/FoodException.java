package com.zosh.FoodAllergenApp.Exception;

public class FoodException extends Exception {

	public FoodException(String message) {
		super(message);

	}

}
