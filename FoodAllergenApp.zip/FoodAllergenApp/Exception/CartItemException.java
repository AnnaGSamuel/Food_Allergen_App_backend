package com.zosh.FoodAllergenApp.Exception;

public class CartItemException extends Exception {
	
	public CartItemException(String message) {
		super(message);
	}

}
